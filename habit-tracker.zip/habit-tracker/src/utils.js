export const dateKey = (d = new Date()) => {
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${d.getFullYear()}-${m}-${day}`;
};

export const addDays = (d, n) => {
  const x = new Date(d);
  x.setDate(x.getDate() + n);
  return x;
};

// Oldest -> newest, ending today
export const lastNDays = (n) =>
  Array.from({ length: n }, (_, i) => addDays(new Date(), i - (n - 1)));

const parseKey = (k) => {
  const [y, m, d] = k.split('-').map(Number);
  return new Date(y, m - 1, d);
};

// completions: array of 'YYYY-MM-DD'
export function calcStreaks(completions) {
  const set = new Set(completions);

  // Current streak: counts back from today (or yesterday if today isn't done yet)
  let current = 0;
  let d = new Date();
  if (!set.has(dateKey(d))) d = addDays(d, -1);
  while (set.has(dateKey(d))) {
    current++;
    d = addDays(d, -1);
  }

  // Longest streak: longest run of consecutive days
  let longest = 0;
  let run = 0;
  let prev = null;
  [...set].sort().forEach((k) => {
    const dt = parseKey(k);
    run = prev && Math.round((dt - prev) / 86400000) === 1 ? run + 1 : 1;
    longest = Math.max(longest, run);
    prev = dt;
  });

  return { current, longest };
}
