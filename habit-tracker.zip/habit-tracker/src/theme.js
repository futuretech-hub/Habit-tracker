export const themes = {
  light: {
    bg: '#F2F5F4', card: '#FFFFFF', text: '#12201E', sub: '#667A76',
    border: '#E0E8E6', primary: '#0F766E', onPrimary: '#FFFFFF',
    track: '#DCE6E3', danger: '#C2410C',
  },
  dark: {
    bg: '#0F1A1C', card: '#17262A', text: '#E8F2F0', sub: '#8FA8A3',
    border: '#243639', primary: '#3CC9B0', onPrimary: '#0A1416',
    track: '#243639', danger: '#FB923C',
  },
};

export const CATEGORIES = [
  { key: 'Study', color: '#4F7CAC' },
  { key: 'Health', color: '#3F9B6B' },
  { key: 'Mind', color: '#8E6BBF' },
  { key: 'Finance', color: '#C9922E' },
];

export const categoryColor = (key) =>
  (CATEGORIES.find((c) => c.key === key) || CATEGORIES[0]).color;

export const EMOJIS = ['📚', '✍️', '🧠', '💧', '🏃', '🥗', '😴', '🧘', '💰', '🎯', '💻', '🎧', '🌿', '🦷', '📝', '☀️'];
