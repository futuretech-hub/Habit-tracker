import React, { useEffect, useState } from 'react';
import { KeyboardAvoidingView, Modal, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { CATEGORIES, EMOJIS, categoryColor } from '../theme';

export default function HabitModal({ visible, habit, t, onClose, onSave, onDelete }) {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('Study');
  const [emoji, setEmoji] = useState('📚');

  useEffect(() => {
    if (visible) {
      setTitle(habit?.title ?? '');
      setCategory(habit?.category ?? 'Study');
      setEmoji(habit?.emoji ?? '📚');
    }
  }, [visible, habit]);

  const canSave = title.trim().length > 0;

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.overlay}>
        <Pressable style={StyleSheet.absoluteFill} onPress={onClose} />
        <View style={[styles.sheet, { backgroundColor: t.bg }]}>
          <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
            <Text style={[styles.heading, { color: t.text }]}>{habit ? 'Edit habit' : 'New habit'}</Text>

            <View style={styles.titleRow}>
              <TextInput
                value={emoji}
                onChangeText={(v) => setEmoji(Array.from(v).slice(-2).join('') || '')}
                style={[styles.emojiInput, { backgroundColor: t.card, borderColor: t.border, color: t.text }]}
                maxLength={4}
              />
              <TextInput
                value={title}
                onChangeText={setTitle}
                placeholder="e.g. Read 20 pages"
                placeholderTextColor={t.sub}
                maxLength={40}
                autoFocus={!habit}
                style={[styles.input, { backgroundColor: t.card, borderColor: t.border, color: t.text }]}
              />
            </View>

            <View style={styles.wrap}>
              {EMOJIS.map((e) => (
                <Pressable key={e} onPress={() => setEmoji(e)} style={[styles.emojiBtn, { backgroundColor: emoji === e ? t.track : 'transparent' }]}>
                  <Text style={{ fontSize: 24 }}>{e}</Text>
                </Pressable>
              ))}
            </View>

            <Text style={[styles.label, { color: t.sub }]}>Category</Text>
            <View style={styles.wrap}>
              {CATEGORIES.map((c) => {
                const on = category === c.key;
                return (
                  <Pressable
                    key={c.key}
                    onPress={() => setCategory(c.key)}
                    style={[styles.chip, { borderColor: c.color, backgroundColor: on ? c.color : 'transparent' }]}
                  >
                    <Text style={{ color: on ? '#fff' : t.text, fontWeight: '600', fontSize: 15 }}>{c.key}</Text>
                  </Pressable>
                );
              })}
            </View>

            <Pressable
              disabled={!canSave}
              onPress={() => onSave({ title, category, emoji: emoji || '🎯' })}
              style={[styles.save, { backgroundColor: t.primary, opacity: canSave ? 1 : 0.4 }]}
            >
              <Text style={[styles.saveText, { color: t.onPrimary }]}>Save habit</Text>
            </Pressable>

            {habit && (
              <Pressable onPress={onDelete} style={styles.delete}>
                <Text style={{ color: t.danger, fontSize: 16, fontWeight: '600' }}>Delete habit</Text>
              </Pressable>
            )}
          </ScrollView>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.45)' },
  sheet: { borderTopLeftRadius: 28, borderTopRightRadius: 28, padding: 22, maxHeight: '90%' },
  heading: { fontSize: 24, fontWeight: '700', marginBottom: 16 },
  titleRow: { flexDirection: 'row', marginBottom: 10 },
  emojiInput: { width: 60, height: 56, borderRadius: 14, borderWidth: 1, textAlign: 'center', fontSize: 26, marginRight: 10 },
  input: { flex: 1, height: 56, borderRadius: 14, borderWidth: 1, paddingHorizontal: 14, fontSize: 17 },
  wrap: { flexDirection: 'row', flexWrap: 'wrap', marginBottom: 8 },
  emojiBtn: { width: 46, height: 46, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  label: { fontSize: 14, fontWeight: '600', marginTop: 10, marginBottom: 8 },
  chip: { paddingHorizontal: 16, height: 44, borderRadius: 22, borderWidth: 2, justifyContent: 'center', marginRight: 8, marginBottom: 8 },
  save: { height: 58, borderRadius: 16, alignItems: 'center', justifyContent: 'center', marginTop: 16 },
  saveText: { fontSize: 18, fontWeight: '700' },
  delete: { height: 52, alignItems: 'center', justifyContent: 'center', marginTop: 6 },
});
