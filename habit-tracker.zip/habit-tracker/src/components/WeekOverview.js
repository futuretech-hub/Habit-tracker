import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { dateKey, lastNDays } from '../utils';

const LETTERS = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
const BAR_H = 72;

export default function WeekOverview({ habits, t }) {
  const days = lastNDays(7).map((d) => {
    const key = dateKey(d);
    const active = habits.filter((h) => h.createdAt <= key);
    const done = active.filter((h) => h.completions.includes(key)).length;
    const rate = active.length ? done / active.length : 0;
    return { key, letter: LETTERS[d.getDay()], rate, isToday: key === dateKey() };
  });

  return (
    <View style={[styles.card, { backgroundColor: t.card, borderColor: t.border }]}>
      <Text style={[styles.title, { color: t.text }]}>Last 7 days</Text>
      <View style={styles.row}>
        {days.map((d) => (
          <View key={d.key} style={styles.col}>
            <Text style={[styles.pct, { color: t.sub }]}>{Math.round(d.rate * 100)}%</Text>
            <View style={[styles.track, { backgroundColor: t.track }]}>
              <View style={[styles.fill, { height: Math.max(d.rate * BAR_H, d.rate > 0 ? 6 : 0), backgroundColor: t.primary }]} />
            </View>
            <Text style={[styles.day, { color: d.isToday ? t.primary : t.sub, fontWeight: d.isToday ? '800' : '500' }]}>{d.letter}</Text>
          </View>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: { borderRadius: 20, borderWidth: 1, padding: 16, marginBottom: 14 },
  title: { fontSize: 16, fontWeight: '700', marginBottom: 12 },
  row: { flexDirection: 'row', justifyContent: 'space-between' },
  col: { flex: 1, alignItems: 'center' },
  pct: { fontSize: 11, marginBottom: 4 },
  track: { width: 26, height: BAR_H, borderRadius: 8, justifyContent: 'flex-end', overflow: 'hidden' },
  fill: { width: '100%', borderRadius: 8 },
  day: { fontSize: 13, marginTop: 6 },
});
