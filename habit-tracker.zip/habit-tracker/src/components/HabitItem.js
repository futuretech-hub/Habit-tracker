import React, { useEffect, useRef } from 'react';
import { Animated, Pressable, StyleSheet, Text, View } from 'react-native';
import { categoryColor } from '../theme';
import { calcStreaks, dateKey } from '../utils';

export default function HabitItem({ habit, t, onToggle, onEdit }) {
  const done = habit.completions.includes(dateKey());
  const { current } = calcStreaks(habit.completions);
  const check = useRef(new Animated.Value(done ? 1 : 0)).current;
  const pop = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    Animated.spring(check, { toValue: done ? 1 : 0, friction: 4, tension: 160, useNativeDriver: true }).start();
    if (done) {
      Animated.sequence([
        Animated.timing(pop, { toValue: 1.04, duration: 90, useNativeDriver: true }),
        Animated.spring(pop, { toValue: 1, useNativeDriver: true }),
      ]).start();
    }
  }, [done]);

  return (
    <Animated.View style={{ transform: [{ scale: pop }] }}>
      <Pressable
        onPress={onToggle}
        onLongPress={onEdit}
        delayLongPress={350}
        accessibilityRole="checkbox"
        accessibilityState={{ checked: done }}
        accessibilityLabel={habit.title}
        style={[styles.row, { backgroundColor: t.card, borderColor: done ? t.primary : t.border }]}
      >
        <Text style={styles.emoji}>{habit.emoji}</Text>
        <View style={styles.mid}>
          <Text
            style={[styles.title, { color: t.text, opacity: done ? 0.55 : 1, textDecorationLine: done ? 'line-through' : 'none' }]}
            numberOfLines={1}
          >
            {habit.title}
          </Text>
          <View style={styles.meta}>
            <View style={[styles.dot, { backgroundColor: categoryColor(habit.category) }]} />
            <Text style={[styles.metaText, { color: t.sub }]}>
              {habit.category}
              {current > 0 ? `  •  🔥 ${current} day${current > 1 ? 's' : ''}` : ''}
            </Text>
          </View>
        </View>
        <View style={[styles.circle, { borderColor: done ? t.primary : t.track, backgroundColor: done ? t.primary : 'transparent' }]}>
          <Animated.Text style={[styles.tick, { color: t.onPrimary, opacity: check, transform: [{ scale: check }] }]}>✓</Animated.Text>
        </View>
      </Pressable>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', minHeight: 76, borderRadius: 18, borderWidth: 1.5, paddingHorizontal: 16, marginBottom: 10 },
  emoji: { fontSize: 30, marginRight: 14 },
  mid: { flex: 1 },
  title: { fontSize: 18, fontWeight: '600' },
  meta: { flexDirection: 'row', alignItems: 'center', marginTop: 4 },
  dot: { width: 8, height: 8, borderRadius: 4, marginRight: 6 },
  metaText: { fontSize: 13 },
  circle: { width: 40, height: 40, borderRadius: 20, borderWidth: 2, alignItems: 'center', justifyContent: 'center' },
  tick: { fontSize: 22, fontWeight: '800', marginTop: -2 },
});
