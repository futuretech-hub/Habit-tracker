import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { calcStreaks } from '../utils';

export default function StatsCard({ habits, t }) {
  const total = habits.reduce((s, h) => s + h.completions.length, 0);
  const best = habits.reduce((m, h) => Math.max(m, calcStreaks(h.completions).longest), 0);
  const items = [
    { label: 'Active habits', value: habits.length },
    { label: 'Total check-ins', value: total },
    { label: 'Longest streak', value: `${best}d` },
  ];
  return (
    <View style={[styles.card, { backgroundColor: t.card, borderColor: t.border }]}>
      {items.map((i) => (
        <View key={i.label} style={styles.item}>
          <Text style={[styles.value, { color: t.primary }]}>{i.value}</Text>
          <Text style={[styles.label, { color: t.sub }]}>{i.label}</Text>
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  card: { flexDirection: 'row', borderRadius: 20, borderWidth: 1, paddingVertical: 16, marginBottom: 14 },
  item: { flex: 1, alignItems: 'center' },
  value: { fontSize: 26, fontWeight: '800' },
  label: { fontSize: 12, marginTop: 2 },
});
