import { useEffect, useState, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { dateKey } from './utils';

const KEY = '@habit_tracker_v1';

export default function useHabits() {
  const [habits, setHabits] = useState([]);
  const [theme, setTheme] = useState(null); // null = follow system
  const [ready, setReady] = useState(false);

  // Load once
  useEffect(() => {
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(KEY);
        if (raw) {
          const data = JSON.parse(raw);
          setHabits(Array.isArray(data.habits) ? data.habits : []);
          if (data.theme) setTheme(data.theme);
        }
      } catch (e) {
        console.warn('Load failed', e);
      }
      setReady(true);
    })();
  }, []);

  // Save on every change (after initial load)
  useEffect(() => {
    if (!ready) return;
    AsyncStorage.setItem(KEY, JSON.stringify({ habits, theme })).catch((e) =>
      console.warn('Save failed', e)
    );
  }, [habits, theme, ready]);

  const addHabit = useCallback(({ title, category, emoji }) => {
    const habit = {
      id: Date.now().toString() + Math.random().toString(36).slice(2, 6),
      title: title.trim(),
      category,
      emoji,
      createdAt: dateKey(),
      completions: [],
    };
    setHabits((h) => [...h, habit]);
  }, []);

  const updateHabit = useCallback((id, fields) => {
    setHabits((h) => h.map((x) => (x.id === id ? { ...x, ...fields, title: (fields.title ?? x.title).trim() } : x)));
  }, []);

  const deleteHabit = useCallback((id) => {
    setHabits((h) => h.filter((x) => x.id !== id));
  }, []);

  const toggleToday = useCallback((id) => {
    const today = dateKey();
    setHabits((h) =>
      h.map((x) => {
        if (x.id !== id) return x;
        const done = x.completions.includes(today);
        return {
          ...x,
          completions: done ? x.completions.filter((k) => k !== today) : [...x.completions, today],
        };
      })
    );
  }, []);

  return { habits, theme, setTheme, ready, addHabit, updateHabit, deleteHabit, toggleToday };
}
