import React, { useState } from 'react';
import { Alert, FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import HabitItem from '../components/HabitItem';
import HabitModal from '../components/HabitModal';
import StatsCard from '../components/StatsCard';
import WeekOverview from '../components/WeekOverview';
import { dateKey } from '../utils';

export default function HomeScreen({ store, t, isDark }) {
  const { habits, addHabit, updateHabit, deleteHabit, toggleToday, setTheme } = store;
  const [modal, setModal] = useState({ open: false, habit: null });

  const today = dateKey();
  const doneCount = habits.filter((h) => h.completions.includes(today)).length;
  const dateLabel = new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' });

  const close = () => setModal({ open: false, habit: null });

  const handleSave = (data) => {
    modal.habit ? updateHabit(modal.habit.id, data) : addHabit(data);
    close();
  };

  const handleDelete = () => {
    Alert.alert('Delete habit?', 'Its history and streaks will be removed.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => { deleteHabit(modal.habit.id); close(); } },
    ]);
  };

  const Header = (
    <View>
      <View style={styles.top}>
        <View style={{ flex: 1 }}>
          <Text style={[styles.date, { color: t.sub }]}>{dateLabel}</Text>
          <Text style={[styles.h1, { color: t.text }]}>
            {habits.length ? `${doneCount} of ${habits.length} done today` : 'Today'}
          </Text>
        </View>
        <Pressable
          onPress={() => setTheme(isDark ? 'light' : 'dark')}
          accessibilityLabel="Toggle dark mode"
          style={[styles.themeBtn, { backgroundColor: t.card, borderColor: t.border }]}
        >
          <Text style={{ fontSize: 22 }}>{isDark ? '☀️' : '🌙'}</Text>
        </Pressable>
      </View>
      <StatsCard habits={habits} t={t} />
      <WeekOverview habits={habits} t={t} />
      <Text style={[styles.section, { color: t.text }]}>Today’s habits</Text>
    </View>
  );

  return (
    <View style={{ flex: 1 }}>
      <FlatList
        data={habits}
        keyExtractor={(h) => h.id}
        ListHeaderComponent={Header}
        renderItem={({ item }) => (
          <HabitItem habit={item} t={t} onToggle={() => toggleToday(item.id)} onEdit={() => setModal({ open: true, habit: item })} />
        )}
        ListEmptyComponent={
          <Text style={[styles.empty, { color: t.sub }]}>No habits yet. Tap + to add your first one.</Text>
        }
        ListFooterComponent={
          habits.length ? <Text style={[styles.hint, { color: t.sub }]}>Press and hold a habit to edit or delete it.</Text> : null
        }
        contentContainerStyle={{ padding: 20, paddingBottom: 120 }}
        showsVerticalScrollIndicator={false}
      />

      <Pressable
        onPress={() => setModal({ open: true, habit: null })}
        accessibilityLabel="Add habit"
        style={[styles.fab, { backgroundColor: t.primary }]}
      >
        <Text style={[styles.plus, { color: t.onPrimary }]}>+</Text>
      </Pressable>

      <HabitModal visible={modal.open} habit={modal.habit} t={t} onClose={close} onSave={handleSave} onDelete={handleDelete} />
    </View>
  );
}

const styles = StyleSheet.create({
  top: { flexDirection: 'row', alignItems: 'center', marginBottom: 16 },
  date: { fontSize: 14, marginBottom: 2 },
  h1: { fontSize: 28, fontWeight: '800' },
  themeBtn: { width: 52, height: 52, borderRadius: 26, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  section: { fontSize: 18, fontWeight: '700', marginBottom: 10 },
  empty: { textAlign: 'center', fontSize: 16, marginTop: 30 },
  hint: { textAlign: 'center', fontSize: 13, marginTop: 10 },
  fab: { position: 'absolute', right: 22, bottom: 28, width: 66, height: 66, borderRadius: 33, alignItems: 'center', justifyContent: 'center', elevation: 6 },
  plus: { fontSize: 36, marginTop: -3, fontWeight: '400' },
});
