import React from 'react';
import { ActivityIndicator, View, useColorScheme } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import HomeScreen from './src/screens/HomeScreen';
import useHabits from './src/useHabits';
import { themes } from './src/theme';

export default function App() {
  const system = useColorScheme();
  const store = useHabits();
  const mode = store.theme || (system === 'dark' ? 'dark' : 'light');
  const t = themes[mode];

  return (
    <SafeAreaProvider>
      <SafeAreaView style={{ flex: 1, backgroundColor: t.bg }}>
        <StatusBar style={mode === 'dark' ? 'light' : 'dark'} />
        {store.ready ? (
          <HomeScreen store={store} t={t} isDark={mode === 'dark'} />
        ) : (
          <View style={{ flex: 1, justifyContent: 'center' }}>
            <ActivityIndicator color={t.primary} size="large" />
          </View>
        )}
      </SafeAreaView>
    </SafeAreaProvider>
  );
}
