# Habit Tracker (Expo + React Native)

## 1. Create the project
npx create-expo-app@latest habit-tracker --template blank
cd habit-tracker
npx expo install @react-native-async-storage/async-storage react-native-safe-area-context expo-status-bar

## 2. Copy files
Replace App.js, app.json (keep any extra fields Expo generated, e.g. icon/splash), add eas.json,
and copy the whole `src/` folder into the project root.

## 3. Run on your Android phone
Install "Expo Go" from Google Play, then:
npx expo start
Scan the QR code with Expo Go (phone and computer on the same Wi-Fi; use `npx expo start --tunnel` if it won't connect).

## 4. Build an APK
npm install -g eas-cli
eas login
eas build:configure
eas build -p android --profile preview
Download the .apk from the link EAS prints, then install it on your phone.
